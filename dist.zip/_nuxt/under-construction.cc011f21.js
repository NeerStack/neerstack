const e=""+new URL("under-construction.8e2d1003.png",import.meta.url).href;export{e as u};
